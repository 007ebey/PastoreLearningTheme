All icons that are included come without a license to use them outside the theme. They can only be used within the theme. For further information about icon licenses please check:

http://picons.me/faq.php
http://budicon.buditanrim.co/license